class RoutesNavigation {
  static const String GaleriScreen = "/";
  static const String PhotoScreen = "/photo-screen";
}