import 'package:assets_dialog_bottomsheet_navigation/constants/assets_constrant.dart';

List<String> imageList = [
  Assets.assetsImagesImages1,
  Assets.assetsImagesImages2,
  Assets.assetsImagesImages3,
  Assets.assetsImagesImages4,
  Assets.assetsImagesImages5,
  Assets.assetsImagesImages6,
  Assets.assetsImagesImages7,
  Assets.assetsImagesImages8,
  Assets.assetsImagesImages9,
  Assets.assetsImagesImages10,
];