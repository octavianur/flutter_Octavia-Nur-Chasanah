class Assets {
  Assets._();
  
  /// Assets for assetsImagesImages1
  /// assets/images/images1.jpg
  static const String assetsImagesImages1 = "assets/images/images1.jpg";

  /// Assets for assetsImagesImages10
  /// assets/images/images10.jpg
  static const String assetsImagesImages10 = "assets/images/images10.jpg";

  /// Assets for assetsImagesImages2
  /// assets/images/images2.jpg
  static const String assetsImagesImages2 = "assets/images/images2.jpg";

  /// Assets for assetsImagesImages3
  /// assets/images/images3.jpg
  static const String assetsImagesImages3 = "assets/images/images3.jpg";

  /// Assets for assetsImagesImages4
  /// assets/images/images4.jpg
  static const String assetsImagesImages4 = "assets/images/images4.jpg";

  /// Assets for assetsImagesImages5
  /// assets/images/images5.jpg
  static const String assetsImagesImages5 = "assets/images/images5.jpg";

  /// Assets for assetsImagesImages6
  /// assets/images/images6.jpg
  static const String assetsImagesImages6 = "assets/images/images6.jpg";

  /// Assets for assetsImagesImages7
  /// assets/images/images7.jpg
  static const String assetsImagesImages7 = "assets/images/images7.jpg";

  /// Assets for assetsImagesImages8
  /// assets/images/images8.jpg
  static const String assetsImagesImages8 = "assets/images/images8.jpg";

  /// Assets for assetsImagesImages9
  /// assets/images/images9.jpg
  static const String assetsImagesImages9 = "assets/images/images9.jpg";
}
