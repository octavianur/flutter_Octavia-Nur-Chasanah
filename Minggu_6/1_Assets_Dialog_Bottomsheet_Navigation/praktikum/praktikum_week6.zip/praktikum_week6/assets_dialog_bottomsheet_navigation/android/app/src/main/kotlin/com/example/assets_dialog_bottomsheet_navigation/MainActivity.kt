package com.example.assets_dialog_bottomsheet_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
